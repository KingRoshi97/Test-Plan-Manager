import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h1>Welcome to KOFA</h1>
      <p>Core feature placeholder. This page is under development.</p>
    </div>
  );
};

export default Home;