import { useEffect, useState } from 'react';
import axios from 'axios';

// Types
interface CoreFeatureResponse {
  status: string;
  data: any; // TODO: [AXION] Define clear data structure
  message?: string;
}

interface UseCoreFeatureReturn {
  data: CoreFeatureResponse | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

// TODO: [AXION] Replace placeholder URL with actual endpoint
const CORE_FEATURE_ENDPOINT = '/api/v1/settings';

export const useCoreFeature = (): UseCoreFeatureReturn => {
  const [data, setData] = useState<CoreFeatureResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get<CoreFeatureResponse>(CORE_FEATURE_ENDPOINT, {
        headers: {
          'Content-Type': 'application/json',
        },
        withCredentials: true,
      });
      setData(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch core feature data');
    } finally {
      setLoading(false);
    }
  };

  const refetch = async () => {
    await fetchData();
  };

  useEffect(() => {
    fetchData();
  }, []);

  return {
    data,
    loading,
    error,
    refetch,
  };
};