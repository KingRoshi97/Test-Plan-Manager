import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

interface ApiConfig {
  baseURL: string;
  timeout?: number;
}

export default class ApiClient {
  private client: AxiosInstance;

  constructor(config: ApiConfig) {
    this.client = axios.create({
      baseURL: config.baseURL,
      timeout: config.timeout || 30000,
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    this.client.interceptors.request.use(
      (config: AxiosRequestConfig) => {
        // TODO: Add token logic here if required
        return config;
      },
      (error) => {
        console.error('Request error:', error);
        return Promise.reject(error);
      }
    );

    this.client.interceptors.response.use(
      (response: AxiosResponse) => response.data,
      (error) => {
        console.error('Response error:', error);
        return Promise.reject(error);
      }
    );
  }

  public get<T = any>(url: string, params?: Record<string, any>): Promise<T> {
    return this.client.get(url, { params });
  }

  public post<T = any>(url: string, data?: Record<string, any>): Promise<T> {
    return this.client.post(url, data);
  }

  public put<T = any>(url: string, data?: Record<string, any>): Promise<T> {
    return this.client.put(url, data);
  }

  public delete<T = any>(url: string, data?: Record<string, any>): Promise<T> {
    return this.client.delete(url, { data });
  }
}