export interface CoreFeatureEntity {
  id: number;
  userId: number;
  title: string;
  data: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateCoreFeatureInput {
  userId: number;
  title: string;
  data?: Record<string, unknown>;
}

export interface UpdateCoreFeatureInput {
  title?: string;
  data?: Record<string, unknown>;
}
