import { Request, Response, NextFunction } from 'express';

/**
 * Custom error handling middleware for the KOFA application.
 * This middleware captures and formats errors occurring in the application.
 *
 * @param {Error} err - The error object.
 * @param {Request} req - The request object.
 * @param {Response} res - The response object.
 * @param {NextFunction} next - The next middleware function.
 */
const errorHandler = (err: Error, req: Request, res: Response, next: NextFunction): void => {
  console.error(`[Error] ${err.name}: ${err.message}`);
  
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  const responsePayload = {
    success: false,
    message: err.message || "An unexpected error occurred.",
    // TODO: [AXION] Extend this object structure for detailed error debugging info if required.
  };

  res.status(statusCode).json(responsePayload);
};

export default errorHandler;