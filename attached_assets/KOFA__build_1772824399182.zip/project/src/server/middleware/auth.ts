import { Request, Response, NextFunction } from 'express';

/**
 * Middleware for authenticating and authorizing requests.
 * This middleware ensures that the accessing user is authenticated
 * and has valid roles/permissions to access the intended resource.
 */

// Placeholder for role enumeration, extend as more roles are added
enum UserRole {
  USER = 'ROLE-001', // "User" role
  // TODO: [AXION] Add additional roles when available
}

/**
 * Ensures the request is authenticated by validating session or token.
 * Redirects or returns an error if authentication fails.
 */
export const authenticate = (req: Request, res: Response, next: NextFunction): void => {
  try {
    // Validate session or access token
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ message: 'Unauthorized access: Missing or invalid token' });
      return;
    }

    const token = authHeader.split(' ')[1];
    // TODO: [AXION] Replace with actual token/session validation logic
    const isValidToken = validateToken(token); // Placeholder
    if (!isValidToken) {
      res.status(401).json({ message: 'Unauthorized access: Invalid token' });
      return;
    }

    // Attach user details to the request object for further usage
    req.user = { id: 'placeholder-id', role: UserRole.USER }; // TODO: Replace with decoded token information
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

/**
 * Role-based Authorization middleware to check if a user
 * has the required role to access a resource.
 *
 * @param {UserRole[]} allowedRoles - List of roles that have access to the resource.
 */
export const authorize = (allowedRoles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      const userRole: UserRole = req.user?.role;

      if (!userRole || !allowedRoles.includes(userRole)) {
        res.status(403).json({ message: 'Forbidden: You do not have access to this resource' });
        return;
      }

      next();
    } catch (error) {
      console.error('Authorization error:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  };
};

/**
 * Placeholder function for token validation.
 * Replace with actual implementation (e.g., JWT verification, session lookup, etc.).
 */
const validateToken = (token: string): boolean => {
  // TODO: [AXION] Implement token validation (e.g., decode and verify JWT)
  return true; // Placeholder result
};

/**
 * Attach extended user data to Request interface (type augmentation)
 */
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        role: UserRole;
        // Add additional user fields as available
      };
    }
  }
}

export default { authenticate, authorize };