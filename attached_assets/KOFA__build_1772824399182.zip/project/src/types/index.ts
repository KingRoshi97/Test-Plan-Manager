export interface CoreFeature {
  id: string;
  createdAt: Date;
  updatedAt: Date;
}

export type UserRole = "ROLE-001";

export type UserRole = "ROLE-001";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt: Date;
  updatedAt: Date;
}