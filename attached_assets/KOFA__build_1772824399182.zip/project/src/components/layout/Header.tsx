import React from 'react';

// Placeholder for potential props
interface HeaderProps {
  // TODO: [AXION] Add necessary props if required in future iterations
}

const Header: React.FC<HeaderProps> = () => {
  return (
    <header
      style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '1rem',
        backgroundColor: '#fff',
        borderBottom: '1px solid #ccc',
      }}
    >
      <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>KOFA</div>
      <nav aria-label="Main navigation">
        <ul
          style={{
            listStyleType: 'none',
            display: 'flex',
            gap: '1rem',
            margin: 0,
            padding: 0,
          }}
        >
          <li>
            <a href="/" style={{ textDecoration: 'none', color: '#007bff' }}>
              Home
            </a>
          </li>
          <li>
            <a href="/about" style={{ textDecoration: 'none', color: '#007bff' }}>
              About
            </a>
          </li>
          <li>
            <a href="/contact" style={{ textDecoration: 'none', color: '#007bff' }}>
              Contact
            </a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;