import React from 'react';
import { NavLink } from 'react-router-dom';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <aside role="complementary" className="sidebar" aria-hidden={!isOpen}>
      <div className="sidebar-overlay" onClick={onClose} tabIndex={0} aria-label="Close sidebar"></div>
      <nav className="sidebar-content" aria-label="Main navigation">
        <ul>
          <li>
            <NavLink to="/" exact activeClassName="active" onClick={onClose}>
              Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/features" activeClassName="active" onClick={onClose}>
              Features
            </NavLink>
          </li>
          <li>
            <NavLink to="/settings" activeClassName="active" onClick={onClose}>
              Settings
            </NavLink>
          </li>
        </ul>
      </nav>
      <button className="sidebar-close" onClick={onClose} aria-label="Close sidebar">
        &times;
      </button>
    </aside>
  );
};

export default Sidebar;