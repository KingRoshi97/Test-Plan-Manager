# 00 — Kit Index

**Run ID**: `RUN-000017`
**Project**: `Axion Generated Project`

## Core Artifacts

| File | Description |
|------|-------------|
| `01_core_artifacts/01_normalized_input_record.json` | Normalized intake submission |
| `01_core_artifacts/02_resolved_standards_snapshot.json` | Resolved standards |
| `01_core_artifacts/03_canonical_spec.json` | Canonical specification |
| `01_core_artifacts/04_work_breakdown.json` | Work breakdown |
| `01_core_artifacts/05_acceptance_map.json` | Acceptance map |
| `01_core_artifacts/06_state_snapshot.json` | State snapshot |

## App Pack Slots

| Slot | Domain |
|------|--------|
| `10_app/01_requirements/` | Requirements & Scope |
| `10_app/02_architecture/` | Architecture & Design |
| `10_app/03_data_models/` | Data Models & Schemas |
| `10_app/04_api_contracts/` | API Contracts & Interfaces |
| `10_app/05_auth_security/` | Auth & Security |
| `10_app/06_frontend/` | Frontend & UI |
| `10_app/07_backend/` | Backend & Services |
| `10_app/08_devops/` | DevOps & Deployment |
| `10_app/09_testing/` | Testing & QA |
| `10_app/10_integrations/` | Integrations |
| `10_app/11_documentation/` | Documentation |
| `10_app/12_analytics/` | Analytics & Monitoring |
