# 00 — Kit Manifest

**Kit ID**: `KIT-RUN-000017`
**Run ID**: `RUN-000017`
**Spec ID**: `SPEC-SUB-1772779288673`
**Project**: `Axion Generated Project`

```json
{
  "manifest_version": "1.0.0",
  "kit_id": "KIT-RUN-000017",
  "run_id": "RUN-000017",
  "spec_id": "SPEC-SUB-1772779288673",
  "work_breakdown_id": "WBD-RUN-000017",
  "acceptance_map_id": "ACCMAP-RUN-000017",
  "state_id": "STATE-RUN-000017",
  "reading_order": [
    "00_START_HERE.md",
    "00_KIT_MANIFEST.md",
    "00_KIT_INDEX.md",
    "00_VERSIONS.md",
    "00_RUN_RULES.md",
    "01_core_artifacts/01_normalized_input_record.json",
    "01_core_artifacts/02_resolved_standards_snapshot.json",
    "01_core_artifacts/03_canonical_spec.json",
    "01_core_artifacts/04_work_breakdown.json",
    "01_core_artifacts/05_acceptance_map.json",
    "01_core_artifacts/06_state_snapshot.json",
    "10_app/"
  ],
  "core_artifacts": {
    "normalized_input": "01_core_artifacts/01_normalized_input_record.json",
    "standards_snapshot": "01_core_artifacts/02_resolved_standards_snapshot.json",
    "canonical_spec": "01_core_artifacts/03_canonical_spec.json",
    "work_breakdown": "01_core_artifacts/04_work_breakdown.json",
    "acceptance_map": "01_core_artifacts/05_acceptance_map.json",
    "state_snapshot": "01_core_artifacts/06_state_snapshot.json"
  },
  "packs": {
    "app": "10_app/"
  },
  "proof": {
    "proof_log": "00_PROOF_LOG.md"
  },
  "run_rules": "00_RUN_RULES.md",
  "versions": {
    "system_version": "1.0.0",
    "intake_form_version": "1.0.0",
    "intake_schema_version": "1.0.0",
    "intake_ruleset_version": "1.0.0",
    "standards_library_version": "1.0.0",
    "resolver_version": "1.0.0",
    "packs_version": "1.0.0",
    "template_library_version": "1.0.0",
    "template_index_version": "1.0.0",
    "fill_rules_version": "1.0.0",
    "templates_used": 174,
    "canonical_model_version": "1.0.0",
    "planning_version": "1.0.0",
    "kit_contracts_version": "1.0.0"
  }
}
```
