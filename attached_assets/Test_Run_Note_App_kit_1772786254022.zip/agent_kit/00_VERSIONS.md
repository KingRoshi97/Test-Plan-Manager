# 00 — Versions

```json
{
  "V-01_system_version": "1.0.0",
  "V-02_intake": {
    "form_version": "1.0.0",
    "schema_version": "1.0.0",
    "int_ruleset": "1.0.0"
  },
  "V-03_standards": {
    "library_version": "1.0.0",
    "resolver_version": "1.0.0",
    "packs_version": "1.0.0"
  },
  "V-04_templates": {
    "library_version": "1.0.0",
    "index_version": "1.0.0",
    "fill_rules_version": "1.0.0",
    "templates_used": 174
  },
  "V-05_canonical_model": "1.0.0",
  "V-06_planning_verification": "1.0.0",
  "V-07_kit_contracts": "1.0.0"
}
```
