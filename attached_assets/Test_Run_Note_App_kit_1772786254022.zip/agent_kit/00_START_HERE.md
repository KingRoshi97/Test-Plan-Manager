# 00 — START HERE

## Purpose & How to Use
This kit contains all artifacts produced by the Axion pipeline for run `RUN-000017`.
It is the authoritative source for the project specification, standards, work breakdown, and acceptance criteria.

## Authoritative Artifacts
- `01_core_artifacts/03_canonical_spec.json` — canonical specification
- `01_core_artifacts/01_normalized_input_record.json` — normalized intake
- `01_core_artifacts/02_resolved_standards_snapshot.json` — resolved standards
- `01_core_artifacts/04_work_breakdown.json` — work breakdown
- `01_core_artifacts/05_acceptance_map.json` — acceptance map
- `01_core_artifacts/06_state_snapshot.json` — current state

## Reading Order
1. Read `00_KIT_MANIFEST.md` for file listing and structure
2. Read `00_VERSIONS.md` for version information
3. Read `01_core_artifacts/03_canonical_spec.json` for project specification
4. Read `01_core_artifacts/04_work_breakdown.json` for work units
5. Read `01_core_artifacts/05_acceptance_map.json` for acceptance criteria
6. Browse `10_app/` for rendered documents by domain

## Execution Loop
1. Load `01_core_artifacts/06_state_snapshot.json` to find `current_unit_id`
2. Open the relevant work unit in `01_core_artifacts/04_work_breakdown.json`
3. Check acceptance criteria in `01_core_artifacts/05_acceptance_map.json`
4. Execute the work unit
5. Record proof in `00_PROOF_LOG.md`
6. Update `01_core_artifacts/06_state_snapshot.json`
7. Advance to next unit

## How to Verify
- Consult `01_core_artifacts/05_acceptance_map.json` for acceptance criteria
- All `hard_gate` items require `proof_required: true`
- Record proof references in `00_PROOF_LOG.md`

## How to Record Progress
Update `01_core_artifacts/06_state_snapshot.json` after completing each unit.

## What Not To Do
- Do not modify core artifact files directly
- Do not skip hard gate acceptance items
- Do not deploy without all gate checks passing

## When Blocked
Record a blocker in `01_core_artifacts/06_state_snapshot.json` under `blockers[]`.

## Completion Definition
All work units have status `done`, all hard_gate acceptance items have status `pass`, and proof is recorded for each.

## Pointers
- Run ID: `RUN-000017`
- Spec ID: `SPEC-SUB-1772779288673`
- Project: `Axion Generated Project`
