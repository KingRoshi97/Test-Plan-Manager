# ERR-03 — API Error Contract (shape,

> **Project:** Test Run Note App | **Spec:** SPEC-SUB-1772779288673 | **Run:** RUN-000017

_Define the canonical error response contract for APIs: payload shape, required fields, status_

---

## 1) Canonical Error Payload Schema (required)

_Error handling strategy to be defined during design._

**Knowledge References:**

- `KID-ITSRE-CHECK-0001`: Observability Baseline Checklist [checklist]
  > ### Metrics
  > - **Define Key Metrics**: Identify metrics that represent the health and performance of your system, such as request rate, error rate, and latency (commonly referred to as the RED metrics)...
- `KID-ITSRE-CHECK-0002`: Incident Readiness Checklist [checklist]
  > ### Monitoring and Observability
  > - **Verify monitoring coverage:** Ensure all critical systems, APIs, and services have monitoring enabled for key metrics (e.g., latency, error rates, CPU/memory usage...
- `KID-ITSRE-CONCEPT-0001`: Logs/Metrics/Traces (what each is for) [concept]
  > Logs, metrics, and traces are the three pillars of observability, each serving a distinct purpose in monitoring and troubleshooting modern software systems.
  > 
  > ### Logs
  > Logs are timestamped records of e...
- `KID-ITSRE-CONCEPT-0002`: SLO/SLI Basics [concept]
  > ### What Are SLIs?
  > A Service Level Indicator (SLI) is a quantifiable measure of a specific aspect of a service’s performance or reliability. Common SLIs include:
  > - **Latency:** The time it takes for a...
- `KID-ITSRE-CONCEPT-0003`: Incident Response Basics [concept]
  > Incident response is a cornerstone of reliability engineering and observability practices. It ensures that organizations can detect, respond to, and recover from disruptions in a systematic and effici...

## "field_errors": [

_Error handling strategy to be defined during design._

**Knowledge References:**

- `KID-ITSRE-CHECK-0001`: Observability Baseline Checklist [checklist]
  > ### Metrics
  > - **Define Key Metrics**: Identify metrics that represent the health and performance of your system, such as request rate, error rate, and latency (commonly referred to as the RED metrics)...
- `KID-ITSRE-CHECK-0002`: Incident Readiness Checklist [checklist]
  > ### Monitoring and Observability
  > - **Verify monitoring coverage:** Ensure all critical systems, APIs, and services have monitoring enabled for key metrics (e.g., latency, error rates, CPU/memory usage...
- `KID-ITSRE-CONCEPT-0001`: Logs/Metrics/Traces (what each is for) [concept]
  > Logs, metrics, and traces are the three pillars of observability, each serving a distinct purpose in monitoring and troubleshooting modern software systems.
  > 
  > ### Logs
  > Logs are timestamped records of e...
- `KID-ITSRE-CONCEPT-0002`: SLO/SLI Basics [concept]
  > ### What Are SLIs?
  > A Service Level Indicator (SLI) is a quantifiable measure of a specific aspect of a service’s performance or reliability. Common SLIs include:
  > - **Latency:** The time it takes for a...
- `KID-ITSRE-CONCEPT-0003`: Incident Response Basics [concept]
  > Incident response is a cornerstone of reliability engineering and observability practices. It ensures that organizations can detect, respond to, and recover from disruptions in a systematic and effici...

## 2) Required/Optional Fields (required)

_Design specifications to be defined during design phase._

## Required: error_id, reason_code, error_class, http_status, correlation_id, timestamp,

_Error handling strategy to be defined during design._

**Knowledge References:**

- `KID-ITSRE-CHECK-0001`: Observability Baseline Checklist [checklist]
  > ### Metrics
  > - **Define Key Metrics**: Identify metrics that represent the health and performance of your system, such as request rate, error rate, and latency (commonly referred to as the RED metrics)...
- `KID-ITSRE-CHECK-0002`: Incident Readiness Checklist [checklist]
  > ### Monitoring and Observability
  > - **Verify monitoring coverage:** Ensure all critical systems, APIs, and services have monitoring enabled for key metrics (e.g., latency, error rates, CPU/memory usage...
- `KID-ITSRE-CONCEPT-0001`: Logs/Metrics/Traces (what each is for) [concept]
  > Logs, metrics, and traces are the three pillars of observability, each serving a distinct purpose in monitoring and troubleshooting modern software systems.
  > 
  > ### Logs
  > Logs are timestamped records of e...
- `KID-ITSRE-CONCEPT-0002`: SLO/SLI Basics [concept]
  > ### What Are SLIs?
  > A Service Level Indicator (SLI) is a quantifiable measure of a specific aspect of a service’s performance or reliability. Common SLIs include:
  > - **Latency:** The time it takes for a...
- `KID-ITSRE-CONCEPT-0003`: Incident Response Basics [concept]
  > Incident response is a cornerstone of reliability engineering and observability practices. It ensures that organizations can detect, respond to, and recover from disruptions in a systematic and effici...

## (message_key OR safe_message)

_Content to be filled during build execution._

## Optional: field_errors, retry_after, docs_url, debug_ref

_Error handling strategy to be defined during design._

**Knowledge References:**

- `KID-ITSRE-CHECK-0001`: Observability Baseline Checklist [checklist]
  > ### Metrics
  > - **Define Key Metrics**: Identify metrics that represent the health and performance of your system, such as request rate, error rate, and latency (commonly referred to as the RED metrics)...
- `KID-ITSRE-CHECK-0002`: Incident Readiness Checklist [checklist]
  > ### Monitoring and Observability
  > - **Verify monitoring coverage:** Ensure all critical systems, APIs, and services have monitoring enabled for key metrics (e.g., latency, error rates, CPU/memory usage...
- `KID-ITSRE-CONCEPT-0001`: Logs/Metrics/Traces (what each is for) [concept]
  > Logs, metrics, and traces are the three pillars of observability, each serving a distinct purpose in monitoring and troubleshooting modern software systems.
  > 
  > ### Logs
  > Logs are timestamped records of e...
- `KID-ITSRE-CONCEPT-0002`: SLO/SLI Basics [concept]
  > ### What Are SLIs?
  > A Service Level Indicator (SLI) is a quantifiable measure of a specific aspect of a service’s performance or reliability. Common SLIs include:
  > - **Latency:** The time it takes for a...
- `KID-ITSRE-CONCEPT-0003`: Incident Response Basics [concept]
  > Incident response is a cornerstone of reliability engineering and observability practices. It ensures that organizations can detect, respond to, and recover from disruptions in a systematic and effici...

## 3) Status Mapping Rules (required)

_Design specifications to be defined during design phase._

## error_class

_Error handling strategy to be defined during design._

**Knowledge References:**

- `KID-ITSRE-CHECK-0001`: Observability Baseline Checklist [checklist]
  > ### Metrics
  > - **Define Key Metrics**: Identify metrics that represent the health and performance of your system, such as request rate, error rate, and latency (commonly referred to as the RED metrics)...
- `KID-ITSRE-CHECK-0002`: Incident Readiness Checklist [checklist]
  > ### Monitoring and Observability
  > - **Verify monitoring coverage:** Ensure all critical systems, APIs, and services have monitoring enabled for key metrics (e.g., latency, error rates, CPU/memory usage...
- `KID-ITSRE-CONCEPT-0001`: Logs/Metrics/Traces (what each is for) [concept]
  > Logs, metrics, and traces are the three pillars of observability, each serving a distinct purpose in monitoring and troubleshooting modern software systems.
  > 
  > ### Logs
  > Logs are timestamped records of e...
- `KID-ITSRE-CONCEPT-0002`: SLO/SLI Basics [concept]
  > ### What Are SLIs?
  > A Service Level Indicator (SLI) is a quantifiable measure of a specific aspect of a service’s performance or reliability. Common SLIs include:
  > - **Latency:** The time it takes for a...
- `KID-ITSRE-CONCEPT-0003`: Incident Response Basics [concept]
  > Incident response is a cornerstone of reliability engineering and observability practices. It ensures that organizations can detect, respond to, and recover from disruptions in a systematic and effici...

## default_status

_Content to be filled during build execution._

## overrides (reason_code

_Content to be filled during build execution._


---

_Generated by AXION Internal Agent | Template: ERR-03 v1.0.0 | 2026-03-06T06:41:38.719Z_