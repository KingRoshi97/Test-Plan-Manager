# App Pack — Index

| Slot | Domain | Files |
|------|--------|-------|
| `01_requirements/` | Requirements & Scope | CDX-01.md, CDX-02.md, CDX-03.md, CDX-04.md, CDX-05.md, DMG-01.md, DMG-02.md, DMG-03.md, DMG-04.md, PRD-01.md, PRD-02.md, PRD-03.md, PRD-04.md, PRD-05.md, PRD-06.md, PRD-07.md, PRD-08.md, PRD-09.md, RISK-01.md, RISK-02.md, RISK-03.md, RISK-04.md, RSC-01.md, RSC-02.md, RSC-03.md, RSC-04.md, URD-01.md, URD-02.md, URD-03.md, URD-04.md, URD-05.md, WFO-01.md, WFO-02.md, WFO-03.md, WFO-04.md, WFO-05.md, WFO-06.md |
| `02_architecture/` | Architecture & Design | ARC-01.md, ARC-02.md, ARC-05.md, ARC-06.md, ARC-07.md, ARC-08.md, ARC-09.md, ARC-10.md, DES-01.md, DES-02.md, DES-03.md, DES-04.md, DES-05.md, DES-06.md, SBDT-01.md, SBDT-02.md, SBDT-03.md, SBDT-04.md, SBDT-05.md, SBDT-06.md |
| `03_data_models/` | Data Models & Schemas | DATA-01.md, DATA-03.md, DATA-04.md, DATA-05.md, DATA-06.md, DATA-07.md, DATA-08.md, DGL-01.md, DGL-02.md, DGL-03.md, DGL-04.md, DGL-05.md, DGL-06.md, DLR-01.md, DLR-02.md, DLR-03.md, DLR-04.md, DLR-05.md, DLR-06.md, DQV-01.md, DQV-02.md, DQV-03.md, DQV-04.md, DQV-05.md, DQV-06.md |
| `04_api_contracts/` | API Contracts & Interfaces | APIG-01.md, APIG-02.md, APIG-03.md, APIG-04.md, APIG-05.md, APIG-06.md |
| `05_auth_security/` | Auth & Security | BRP-01.md, BRP-02.md, BRP-03.md, BRP-04.md, PMAD-01.md, PMAD-02.md, PMAD-03.md, PMAD-04.md, PMAD-05.md, PMAD-06.md, STK-01.md, STK-02.md, STK-03.md, STK-04.md |
| `06_frontend/` | Frontend & UI | A11YD-01.md, A11YD-02.md, A11YD-03.md, A11YD-04.md, A11YD-05.md, DES-07.md, DES-08.md, DSYS-01.md, DSYS-02.md, DSYS-03.md, DSYS-04.md, DSYS-05.md, IAN-01.md, IAN-02.md, IAN-03.md, IAN-04.md, IAN-05.md, IXD-01.md, IXD-02.md, IXD-03.md, IXD-04.md, IXD-05.md, RLB-01.md, RLB-02.md, RLB-03.md, RLB-04.md, RLB-05.md, VAP-01.md, VAP-02.md, VAP-03.md, VAP-04.md, VAP-05.md |
| `07_backend/` | Backend & Services | CACHE-01.md, CACHE-02.md, CACHE-03.md, CACHE-04.md, CACHE-05.md, CACHE-06.md, ERR-01.md, ERR-02.md, ERR-03.md, ERR-04.md, ERR-05.md, ERR-06.md, RTM-01.md, RTM-02.md, RTM-03.md, RTM-04.md, RTM-05.md, RTM-06.md, SRCH-01.md, SRCH-02.md, SRCH-03.md, SRCH-04.md, SRCH-05.md, SRCH-06.md |
| `08_devops/` | DevOps & Deployment | 00_NA.md |
| `09_testing/` | Testing & QA | 00_NA.md |
| `10_integrations/` | Integrations | SIC-01.md, SIC-02.md, SIC-03.md, SIC-04.md, SIC-05.md, SIC-06.md |
| `11_documentation/` | Documentation | 00_NA.md |
| `12_analytics/` | Analytics & Monitoring | RPT-01.md, RPT-02.md, RPT-03.md, RPT-04.md, RPT-05.md, RPT-06.md, SMIP-01.md, SMIP-02.md, SMIP-03.md, SMIP-04.md |
