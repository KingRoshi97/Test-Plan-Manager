# 00 — Run Rules

## Rules

1. **No claims without proof** — Do not mark a work unit as done without recording proof in `00_PROOF_LOG.md`
2. **Update state snapshot** — After completing each unit, update `01_core_artifacts/06_state_snapshot.json`
3. **Follow work breakdown order** — Execute units in the order defined in `01_core_artifacts/04_work_breakdown.json`
4. **Hard gates are blocking** — All acceptance items with `gating: "hard_gate"` must pass before moving forward
5. **No modification of core artifacts** — Do not edit files in `01_core_artifacts/` directly
6. **Gate checks before deployment** — All gate reports must show `pass` before any deployment step
