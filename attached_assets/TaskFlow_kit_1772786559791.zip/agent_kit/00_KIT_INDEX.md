# 00 — Kit Index

**Run ID**: `RUN-000021`
**Project**: `Axion Generated Project`

## Core Artifacts

| File | Description |
|------|-------------|
| `01_core_artifacts/01_normalized_input_record.json` | Normalized intake submission |
| `01_core_artifacts/02_resolved_standards_snapshot.json` | Resolved standards |
| `01_core_artifacts/03_canonical_spec.json` | Canonical specification |
| `01_core_artifacts/04_work_breakdown.json` | Work breakdown |
| `01_core_artifacts/05_acceptance_map.json` | Acceptance map |
| `01_core_artifacts/06_state_snapshot.json` | State snapshot |

## App Pack Slots

| Slot | Domain |
|------|--------|
| `10_app/01_requirements/` | Requirements |
| `10_app/02_design/` | Design |
| `10_app/03_architecture/` | Architecture |
| `10_app/04_implementation/` | Implementation |
| `10_app/05_security/` | Security |
| `10_app/06_quality/` | Quality |
| `10_app/07_ops/` | Operations |
| `10_app/08_data/` | Data |
| `10_app/09_api_contracts/` | API Contracts |
| `10_app/10_release/` | Release |
| `10_app/11_governance/` | Governance |
| `10_app/12_analytics/` | Analytics |
