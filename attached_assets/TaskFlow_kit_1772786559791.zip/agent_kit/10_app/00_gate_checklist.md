# App Pack — Gate Checklist

**Run ID**: `RUN-000021`

| Gate | Target | Status |
|------|--------|--------|
| G1_INTAKE_VALIDITY | intake/validation_result.json | (check run) |
| G2_CANONICAL_INTEGRITY | canonical/canonical_spec.json | (check run) |
| G3_STANDARDS_RESOLVED | standards/resolved_standards_snapshot.json | (check run) |
| G4_TEMPLATE_SELECTION | templates/selection_result.json | (check run) |
| G5_TEMPLATE_COMPLETENESS | templates/template_completeness_report.json | (check run) |
| G6_PLAN_COVERAGE | planning/coverage_report.json | (check run) |
| G7_VERIFICATION | verification/verification_run_result.json | (check run) |
| G8_PACKAGE_INTEGRITY | kit/kit_manifest.json | (check run) |
