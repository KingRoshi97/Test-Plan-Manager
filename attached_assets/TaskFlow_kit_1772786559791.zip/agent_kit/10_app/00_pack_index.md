# App Pack — Index

| Slot | Domain | Files |
|------|--------|-------|
| `01_requirements/` | Requirements | CDX-01.md, CDX-02.md, CDX-03.md, CDX-04.md, CDX-05.md, DMG-01.md, DMG-02.md, DMG-03.md, DMG-04.md, PRD-01.md, PRD-02.md, PRD-03.md, PRD-04.md, PRD-05.md, PRD-06.md, PRD-07.md, PRD-08.md, PRD-09.md |
| `02_design/` | Design | DES-02.md, DES-03.md, DES-04.md, DES-05.md, DES-06.md, DES-07.md, DES-08.md, DSYS-01.md, DSYS-02.md, DSYS-03.md, DSYS-04.md, DSYS-05.md, IAN-01.md, IAN-02.md, IAN-03.md, IAN-04.md, IAN-05.md, IXD-01.md, IXD-02.md, IXD-03.md, IXD-04.md, IXD-05.md, RLB-01.md, RLB-02.md, RLB-03.md, RLB-04.md, RLB-05.md, VAP-01.md, VAP-02.md, VAP-03.md, VAP-04.md, VAP-05.md |
| `03_architecture/` | Architecture | ARC-01.md, ARC-02.md, ARC-05.md, ARC-06.md, ARC-07.md, ARC-08.md, ARC-09.md, ARC-10.md |
| `04_implementation/` | Implementation | CER-01.md, CER-02.md, CER-03.md, CER-04.md, CER-05.md, FE-01.md, FE-02.md, FE-03.md, FE-04.md, FE-05.md, FE-06.md, FE-07.md, FORM-01.md, FORM-02.md, FORM-03.md, FORM-04.md, FORM-05.md, FORM-06.md, ROUTE-01.md, ROUTE-02.md, ROUTE-03.md, ROUTE-04.md, ROUTE-05.md, ROUTE-06.md, SIC-01.md, SIC-02.md, SIC-03.md, SIC-04.md, SIC-05.md, SIC-06.md, SMD-01.md, SMD-02.md, SMD-03.md, SMD-04.md, SMD-05.md, SMD-06.md, UICP-01.md, UICP-02.md, UICP-03.md, UICP-04.md, UICP-05.md |
| `05_security/` | Security | 00_NA.md |
| `06_quality/` | Quality | 00_NA.md |
| `07_ops/` | Operations | 00_NA.md |
| `08_data/` | Data | DATA-01.md, DATA-03.md, DATA-04.md, DATA-05.md, DATA-06.md, DATA-07.md, DATA-08.md |
| `09_api_contracts/` | API Contracts | API-01.md, API-02.md, API-03.md, API-04.md, API-05.md, API-06.md, API-07.md, APIG-01.md, APIG-02.md, APIG-03.md, APIG-04.md, APIG-05.md, APIG-06.md, PFS-01.md, PFS-02.md, PFS-03.md, PFS-04.md, PFS-05.md |
| `10_release/` | Release | 00_NA.md |
| `11_governance/` | Governance | 00_NA.md |
| `12_analytics/` | Analytics | 00_NA.md |
